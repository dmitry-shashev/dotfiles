/*
 * Copyright 2003-2023 The IdeaVim authors
 *
 * Use of this source code is governed by an MIT-style
 * license that can be found in the LICENSE.txt file or at
 * https://opensource.org/licenses/MIT.
 */

package com.maddyhome.idea.vim.vimscript.model.commands

object IntellijExCommandProvider : ExCommandProvider {
  override val exCommandsFileName: String = "intellij_ex_commands.json"
}